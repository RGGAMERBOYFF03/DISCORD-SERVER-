const {
  Client,
  GatewayIntentBits,
  REST,
  Routes,
  SlashCommandBuilder,
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  Events,
  PermissionFlagsBits,
} = require("discord.js");
const fs = require("node:fs");
const path = require("node:path");
const crypto = require("node:crypto");

require("dotenv").config();

const required = ["DISCORD_TOKEN", "CLIENT_ID", "GUILD_ID"];
for (const name of required) {
  if (!process.env[name]) {
    console.error(`Missing required environment variable: ${name}`);
    process.exit(1);
  }
}

const ROLE_IDS = {
  owner: process.env.OWNER_ROLE_ID || "",
  admin: process.env.ADMIN_ROLE_ID || "",
  moderator: process.env.MODERATOR_ROLE_ID || "",
  staff: process.env.STAFF_ROLE_ID || "",
};

const DATA_DIR = path.join(__dirname, "data");
const KEY_FILE = path.join(DATA_DIR, "keys.json");
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(KEY_FILE)) fs.writeFileSync(KEY_FILE, "[]", "utf8");

function readKeys() {
  try {
    return JSON.parse(fs.readFileSync(KEY_FILE, "utf8"));
  } catch {
    return [];
  }
}
function writeKeys(keys) {
  fs.writeFileSync(KEY_FILE, JSON.stringify(keys, null, 2), "utf8");
}
function getRoleType(member) {
  // Highest privilege wins. Configure role IDs in the host's environment variables.
  if (ROLE_IDS.owner && member.roles.cache.has(ROLE_IDS.owner)) return "Owner";
  if (ROLE_IDS.admin && member.roles.cache.has(ROLE_IDS.admin)) return "Admin";
  if (ROLE_IDS.moderator && member.roles.cache.has(ROLE_IDS.moderator)) return "Moderator";
  if (ROLE_IDS.staff && member.roles.cache.has(ROLE_IDS.staff)) return "Staff";
  return null;
}
function createKey() {
  return `RH-${crypto.randomBytes(12).toString("hex").toUpperCase()}`;
}

const client = new Client({
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers],
});

const commands = [
  new SlashCommandBuilder()
    .setName("key")
    .setDescription("Open the staff website key panel"),
  new SlashCommandBuilder()
    .setName("keypanel")
    .setDescription("Post the Key System panel (staff/admin permission required)")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild),
].map((c) => c.toJSON());

async function registerCommands() {
  const rest = new REST({ version: "10" }).setToken(process.env.DISCORD_TOKEN);
  await rest.put(
    Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
    { body: commands }
  );
  console.log("Slash commands registered.");
}

client.once(Events.ClientReady, (readyClient) => {
  console.log(`Logged in as ${readyClient.user.tag}`);
});

client.on(Events.InteractionCreate, async (interaction) => {
  try {
    if (!interaction.inGuild()) {
      if (interaction.isRepliable()) {
        await interaction.reply({ content: "Please use this command inside the server.", ephemeral: true });
      }
      return;
    }

    if (interaction.isChatInputCommand() && interaction.commandName === "key") {
      const embed = new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle("🔑 KEY SYSTEM")
        .setDescription([
          "Welcome to the staff access key panel.",
          "",
          "**What is a Key?**",
          "A key is a code intended to identify your access request for the staff website.",
          "",
          "**How to use it**",
          "1. Press **Get Key** below.",
          "2. Keep your key private.",
          "3. Enter it on the staff website when that integration is available.",
          "",
          "Only approved Staff, Moderators, Admins, and Owners can receive a key.",
        ].join("\n"))
        .setFooter({ text: "Never share your key or bot token." });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("get_staff_key")
          .setLabel("Get Key")
          .setEmoji("🔑")
          .setStyle(ButtonStyle.Primary)
      );

      await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });
      return;
    }

    if (interaction.isChatInputCommand() && interaction.commandName === "keypanel") {
      const embed = new EmbedBuilder()
        .setColor(0x5865f2)
        .setTitle("🔑 KEY SYSTEM")
        .setDescription([
          "Use the button below to request your staff website key.",
          "",
          "**How to use it:**",
          "• Click **Get Key**.",
          "• Your Discord role will be checked.",
          "• If eligible, your key will be sent privately.",
          "",
          "Do not share your key with anyone.",
        ].join("\n"))
        .setFooter({ text: "Staff access • Role-verified" });

      const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
          .setCustomId("get_staff_key")
          .setLabel("Get Key")
          .setEmoji("🔑")
          .setStyle(ButtonStyle.Primary)
      );

      await interaction.channel.send({ embeds: [embed], components: [row] });
      await interaction.reply({ content: "Key panel posted.", ephemeral: true });
      return;
    }

    if (interaction.isButton() && interaction.customId === "get_staff_key") {
      await interaction.deferReply({ ephemeral: true });
      const member = await interaction.guild.members.fetch(interaction.user.id);
      const roleType = getRoleType(member);

      if (!roleType) {
        await interaction.editReply("❌ You do not have an eligible Staff, Moderator, Admin, or Owner role.");
        return;
      }

      const keys = readKeys();
      const existing = keys.find((k) => k.discordUserId === interaction.user.id && k.status === "active");

      if (existing) {
        await interaction.editReply(
          `✅ You already have an active **${existing.roleType}** key:\n\`${existing.key}\`\n\nKeep it private. If your Discord role has changed, contact the Owner to review access.`
        );
        return;
      }

      const key = createKey();
      keys.push({
        key,
        discordUserId: interaction.user.id,
        discordUsername: interaction.user.username,
        guildId: interaction.guildId,
        roleType,
        status: "active",
        createdAt: new Date().toISOString(),
      });
      writeKeys(keys);

      await interaction.editReply(
        `✅ Your **${roleType}** key has been created:\n\`${key}\`\n\nKeep it private. This starter bot stores keys in a local JSON file. Connect it to a secured database before using it for real website access.`
      );
      return;
    }
  } catch (error) {
    console.error("Interaction error:", error);
    const message = "Something went wrong. Please try again or contact the bot owner.";
    if (interaction.deferred || interaction.replied) {
      await interaction.editReply(message).catch(() => {});
    } else if (interaction.isRepliable()) {
      await interaction.reply({ content: message, ephemeral: true }).catch(() => {});
    }
  }
});

(async () => {
  try {
    await registerCommands();
    await client.login(process.env.DISCORD_TOKEN);
  } catch (error) {
    console.error("Startup failed:", error);
    process.exit(1);
  }
})();
