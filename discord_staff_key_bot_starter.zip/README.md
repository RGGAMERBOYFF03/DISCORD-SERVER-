# Discord Staff Key Bot (starter)

This is a starter Discord.js bot for a staff Key System. It includes:
- `/key` — privately opens the Key System panel.
- `/keypanel` — posts a public panel in the current channel (requires Manage Server).
- `Get Key` button — checks the member's configured Discord role and issues one active key per Discord user.
- Key records are stored in `data/keys.json`.

## Important security limitations
This is a starter/demo, **not a production-ready website authentication system**. It does not connect to Firebase or a website yet. Local JSON storage can be lost on some hosting providers' redeploys/restarts, and keys by themselves must not grant roles unless the website verifies them securely on a server. Before using real staff access, connect the bot and website to a secured database/API and implement server-side authorization.

## Setup
1. Create a Discord application and bot at https://discord.com/developers/applications
2. Invite the bot to your server with `bot` and `applications.commands` scopes. It needs permission to send messages and embed links.
3. Copy this project to your host or repository.
4. Install Node.js 20+ and run:
   ```bash
   npm install
   npm start
   ```
5. Set the variables listed in `.env.example` in your host's **Environment Variables / Secrets** settings.
6. Copy the Application ID into `CLIENT_ID`, your server ID into `GUILD_ID`, and the exact role IDs into the role variables.
7. Start/restart the service. Commands are registered to the configured server.

## Do not expose secrets
- Never upload a real bot token to GitHub.
- Do not paste the token into chat.
- If a token is accidentally exposed, reset it in Discord Developer Portal immediately.
- Add `.env` and `data/keys.json` to `.gitignore` (already included).

## Customizing the panel image
The current panel is an embed without a custom image. To add one, set a valid image URL in code using `.setImage("https://...")`, or host your image and use its direct image URL.
